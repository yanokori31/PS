"""
Basic math functions for PCS.
"""

import math
from typing import Union


class EvaluationResult:
    """Local EvaluationResult class compatible with the main evaluator."""
    def __init__(self, value, display_type: str = "number"):
        self.value = value
        self.display_type = display_type


def _get_value(x) -> float:
    if hasattr(x, 'value'):
        return x.value
    return x


def sqrt(x) -> EvaluationResult:
    """Square root function."""
    val = _get_value(x)
    if val < 0:
        raise ValueError("Cannot compute square root of negative number")
    return EvaluationResult(math.sqrt(val))


def pow(base, exponent) -> EvaluationResult:
    """Power function: base^exponent."""
    b = _get_value(base)
    e = _get_value(exponent)
    return EvaluationResult(b ** e)


def mod(a, b) -> EvaluationResult:
    """Modulo function: a % b."""
    av = _get_value(a)
    bv = _get_value(b)
    if bv == 0:
        raise ValueError("Modulo by zero")
    return EvaluationResult(av % bv)


def floor(x) -> EvaluationResult:
    """Floor function: round down to nearest integer."""
    val = _get_value(x)
    return EvaluationResult(math.floor(val))


def ceil(x) -> EvaluationResult:
    """Ceiling function: round up to nearest integer."""
    val = _get_value(x)
    return EvaluationResult(math.ceil(val))


def round_num(x, decimals=None) -> EvaluationResult:
    """Round to specified decimal places."""
    val = _get_value(x)
    if decimals is not None:
        d = int(_get_value(decimals))
        return EvaluationResult(round(val, d))
    return EvaluationResult(round(val))


def max_val(*args) -> EvaluationResult:
    """Maximum of values."""
    values = [_get_value(a) for a in args]
    return EvaluationResult(max(values))


def min_val(*args) -> EvaluationResult:
    """Minimum of values."""
    values = [_get_value(a) for a in args]
    return EvaluationResult(min(values))


def gcd(a, b) -> EvaluationResult:
    """Greatest common divisor."""
    av = int(_get_value(a))
    bv = int(_get_value(b))
    return EvaluationResult(math.gcd(av, bv))


def lcm(a, b) -> EvaluationResult:
    """Least common multiple."""
    av = int(_get_value(a))
    bv = int(_get_value(b))
    return EvaluationResult(abs(av * bv) // math.gcd(av, bv))


FUNCTIONS = {
    'sqrt': sqrt,
    'pow': pow,
    'mod': mod,
    'floor': floor,
    'ceil': ceil,
    'round': round_num,
    'max': max_val,
    'min': min_val,
    'gcd': gcd,
    'lcm': lcm,
}
