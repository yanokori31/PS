"""
Parser for PCS - builds Abstract Syntax Tree from tokens.
"""

from typing import List, Optional, Dict, Callable, Any
from .tokenizer import Token, TokenType, Tokenizer


class ASTNode:
    pass


class NumberNode(ASTNode):
    def __init__(self, value: float):
        self.value = value
    
    def __repr__(self):
        return f"NumberNode({self.value})"


class BinaryOpNode(ASTNode):
    def __init__(self, left: ASTNode, operator: str, right: ASTNode):
        self.left = left
        self.operator = operator
        self.right = right
    
    def __repr__(self):
        return f"BinaryOpNode({self.left}, '{self.operator}', {self.right})"


class UnaryOpNode(ASTNode):
    def __init__(self, operator: str, operand: ASTNode):
        self.operator = operator
        self.operand = operand
    
    def __repr__(self):
        return f"UnaryOpNode('{self.operator}', {self.operand})"


class FunctionCallNode(ASTNode):
    def __init__(self, name: str, arguments: List[ASTNode]):
        self.name = name
        self.arguments = arguments
    
    def __repr__(self):
        return f"FunctionCallNode({self.name}, {self.arguments})"


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.current_token = self.tokens[0] if tokens else None
    
    def advance(self):
        self.pos += 1
        if self.pos < len(self.tokens):
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = Token(TokenType.EOF, None)
    
    def eat(self, token_type: TokenType):
        if self.current_token.type == token_type:
            self.advance()
        else:
            raise SyntaxError(f"Expected {token_type.name}, got {self.current_token.type.name}")
    
    def parse(self) -> ASTNode:
        result = self.expression()
        if self.current_token.type != TokenType.EOF:
            raise SyntaxError(f"Unexpected token: {self.current_token}")
        return result
    
    def expression(self) -> ASTNode:
        node = self.term()
        
        while self.current_token.type in (TokenType.PLUS, TokenType.MINUS):
            op = self.current_token.value
            self.advance()
            node = BinaryOpNode(node, op, self.term())
        
        return node
    
    def term(self) -> ASTNode:
        node = self.factor()
        
        while self.current_token.type in (TokenType.MULTIPLY, TokenType.DIVIDE):
            op = self.current_token.value
            if op == '\u00d7':
                op = '*'
            elif op == '\u00f7':
                op = '/'
            self.advance()
            node = BinaryOpNode(node, op, self.factor())
        
        return node
    
    def factor(self) -> ASTNode:
        token = self.current_token
        
        if token.type == TokenType.PLUS:
            self.advance()
            return UnaryOpNode('+', self.factor())
        
        if token.type == TokenType.MINUS:
            self.advance()
            return UnaryOpNode('-', self.factor())
        
        if token.type == TokenType.NUMBER:
            self.advance()
            return NumberNode(token.value)
        
        if token.type == TokenType.FUNCTION:
            return self.function_call()
        
        if token.type == TokenType.LPAREN:
            self.advance()
            node = self.expression()
            self.eat(TokenType.RPAREN)
            return node
        
        raise SyntaxError(f"Unexpected token: {token}")
    
    def function_call(self) -> ASTNode:
        name = self.current_token.value
        self.advance()
        
        if self.current_token.type != TokenType.LPAREN:
            raise SyntaxError(f"Expected '(' after function name '{name}'")
        
        self.advance()
        
        arguments = []
        if self.current_token.type != TokenType.RPAREN:
            arguments.append(self.expression())
            
            while self.current_token.type == TokenType.COMMA:
                self.advance()
                arguments.append(self.expression())
        
        self.eat(TokenType.RPAREN)
        
        return FunctionCallNode(name, arguments)
