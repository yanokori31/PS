"""
Fraction utilities for PCS - helper functions for fraction operations.
"""

from fractions import Fraction
from typing import Union, Tuple

NumType = Union[int, float, Fraction]


def frac(numerator: NumType, denominator: NumType) -> Fraction:
    """
    Create a fraction from numerator and denominator.
    
    Args:
        numerator: The top number of the fraction
        denominator: The bottom number of the fraction
        
    Returns:
        A Fraction object representing numerator/denominator
        
    Examples:
        >>> frac(1, 2)
        Fraction(1, 2)
        >>> frac(3, 4)
        Fraction(3, 4)
    """
    if denominator == 0:
        raise ValueError("Denominator cannot be zero")
    
    num_val: NumType = numerator
    den_val: NumType = denominator
    
    if isinstance(num_val, float) and not num_val.is_integer():
        num_val = Fraction(num_val).limit_denominator(10000)
    if isinstance(den_val, float) and not den_val.is_integer():
        den_val = Fraction(den_val).limit_denominator(10000)
    
    return Fraction(int(num_val), int(den_val))


def mixf(whole: int, numerator: int, denominator: int) -> Fraction:
    """
    Create a fraction from a mixed number (whole + fraction).
    
    Args:
        whole: The whole number part
        numerator: The numerator of the fractional part
        denominator: The denominator of the fractional part
        
    Returns:
        A Fraction object representing whole + numerator/denominator
        
    Examples:
        >>> mixf(1, 1, 2)  # 1 1/2 = 3/2
        Fraction(3, 2)
        >>> mixf(2, 3, 4)  # 2 3/4 = 11/4
        Fraction(11, 4)
    """
    if denominator == 0:
        raise ValueError("Denominator cannot be zero")
    
    sign = 1 if whole >= 0 else -1
    whole = abs(int(whole))
    numerator = int(numerator)
    denominator = int(denominator)
    
    total_numerator = whole * denominator + numerator
    return Fraction(sign * total_numerator, denominator)


def fraction_to_mixed(f: Fraction) -> Tuple[int, int, int]:
    """
    Convert a fraction to mixed number components.
    
    Args:
        f: A Fraction object
        
    Returns:
        Tuple of (whole, numerator, denominator)
        
    Examples:
        >>> fraction_to_mixed(Fraction(7, 4))
        (1, 3, 4)
        >>> fraction_to_mixed(Fraction(-5, 2))
        (-2, 1, 2)
    """
    sign = 1 if f >= 0 else -1
    f_abs = abs(f)
    
    whole = int(f_abs)
    remainder = f_abs - whole
    
    return (sign * whole, remainder.numerator, remainder.denominator)


def simplify(numerator: int, denominator: int) -> Tuple[int, int]:
    """
    Simplify a fraction to its lowest terms.
    
    Args:
        numerator: The numerator
        denominator: The denominator
        
    Returns:
        Tuple of (simplified_numerator, simplified_denominator)
    """
    f = Fraction(numerator, denominator)
    return (f.numerator, f.denominator)
