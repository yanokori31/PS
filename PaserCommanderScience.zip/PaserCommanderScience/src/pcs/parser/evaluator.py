"""
Evaluator for PCS - evaluates the AST and computes results.
"""

from typing import Dict, Callable, Any, Union
from fractions import Fraction
from decimal import Decimal, getcontext
from .parser import ASTNode, NumberNode, BinaryOpNode, UnaryOpNode, FunctionCallNode

getcontext().prec = 50


class EvaluationResult:
    def __init__(self, value: Any, display_type: str = "number"):
        self.value = value
        self.display_type = display_type
    
    def __repr__(self):
        return f"EvaluationResult({self.value}, {self.display_type})"
    
    def to_number(self) -> float:
        if isinstance(self.value, Fraction):
            return float(self.value)
        if isinstance(self.value, Decimal):
            return float(self.value)
        return float(self.value)


class Evaluator:
    def __init__(self):
        self.functions: Dict[str, Callable] = {}
        self._register_builtin_functions()
    
    def _register_builtin_functions(self):
        self.functions['frac'] = self._frac
        self.functions['mixf'] = self._mixf
        self.functions['dec'] = self._decimal
        self.functions['abs'] = lambda x: EvaluationResult(abs(self._get_value(x)))
    
    def _get_value(self, result: Union[EvaluationResult, float, int]) -> Any:
        if hasattr(result, 'value'):
            return result.value
        return result
    
    def _frac(self, numerator, denominator) -> EvaluationResult:
        num = self._get_value(numerator)
        den = self._get_value(denominator)
        
        if den == 0:
            raise ValueError("Division by zero in fraction")
        
        if isinstance(num, float) and not num.is_integer():
            num = Fraction(num).limit_denominator(10000)
        if isinstance(den, float) and not den.is_integer():
            den = Fraction(den).limit_denominator(10000)
            
        fraction = Fraction(int(num), int(den))
        return EvaluationResult(fraction, "fraction")
    
    def _mixf(self, whole, numerator, denominator) -> EvaluationResult:
        w = self._get_value(whole)
        num = self._get_value(numerator)
        den = self._get_value(denominator)
        
        if den == 0:
            raise ValueError("Division by zero in mixed fraction")
        
        sign = 1 if w >= 0 else -1
        w = abs(int(w))
        num = int(num)
        den = int(den)
        
        total_numerator = w * den + num
        fraction = Fraction(sign * total_numerator, den)
        return EvaluationResult(fraction, "mixed_fraction")
    
    def _decimal(self, value, precision=None) -> EvaluationResult:
        val = self._get_value(value)
        if precision is not None:
            prec = int(self._get_value(precision))
            dec_val = round(Decimal(str(val)), prec)
        else:
            dec_val = Decimal(str(val))
        return EvaluationResult(dec_val, "decimal")
    
    def register_function(self, name: str, func: Callable):
        self.functions[name] = func
    
    def evaluate(self, node: ASTNode) -> EvaluationResult:
        if isinstance(node, NumberNode):
            return EvaluationResult(node.value)
        
        if isinstance(node, BinaryOpNode):
            left = self.evaluate(node.left)
            right = self.evaluate(node.right)
            
            left_val = self._get_value(left)
            right_val = self._get_value(right)
            
            if node.operator == '+':
                result = left_val + right_val
            elif node.operator == '-':
                result = left_val - right_val
            elif node.operator == '*':
                result = left_val * right_val
            elif node.operator == '/':
                if right_val == 0:
                    raise ValueError("Division by zero")
                result = left_val / right_val
            else:
                raise ValueError(f"Unknown operator: {node.operator}")
            
            display_type = "number"
            if isinstance(result, Fraction):
                display_type = "fraction"
            elif isinstance(result, Decimal):
                display_type = "decimal"
            
            return EvaluationResult(result, display_type)
        
        if isinstance(node, UnaryOpNode):
            operand = self.evaluate(node.operand)
            val = self._get_value(operand)
            
            if node.operator == '+':
                return EvaluationResult(val, operand.display_type)
            elif node.operator == '-':
                return EvaluationResult(-val, operand.display_type)
            else:
                raise ValueError(f"Unknown unary operator: {node.operator}")
        
        if isinstance(node, FunctionCallNode):
            if node.name not in self.functions:
                raise ValueError(f"Unknown function: {node.name}")
            
            args = [self.evaluate(arg) for arg in node.arguments]
            return self.functions[node.name](*args)
        
        raise ValueError(f"Unknown node type: {type(node)}")
