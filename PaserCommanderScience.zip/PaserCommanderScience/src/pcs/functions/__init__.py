"""
Functions module for PCS - extensible custom functions.

This module provides a plugin system for adding custom functions to PCS.
Users can create new Python files in this directory to add their own functions.

Example: Create a file named 'my_functions.py' with:

    from ..parser.evaluator import EvaluationResult
    
    def square(x):
        val = x.value if hasattr(x, 'value') else x
        return EvaluationResult(val ** 2)
    
    def cube(x):
        val = x.value if hasattr(x, 'value') else x
        return EvaluationResult(val ** 3)
    
    FUNCTIONS = {
        'square': square,
        'cube': cube,
    }

Then in your PCS code, use:
    square(5)  -> 25
    cube(3)    -> 27
"""

import os
import importlib
import importlib.util
from typing import Dict, Callable


def load_custom_functions() -> Dict[str, Callable]:
    """
    Load all custom functions from Python files in the functions directory.
    
    Returns:
        Dictionary mapping function names to callable functions.
    """
    functions = {}
    functions_dir = os.path.dirname(__file__)
    
    for filename in os.listdir(functions_dir):
        if filename.endswith('.py') and not filename.startswith('_'):
            module_name = filename[:-3]
            module_path = os.path.join(functions_dir, filename)
            
            try:
                spec = importlib.util.spec_from_file_location(module_name, module_path)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    if hasattr(module, 'FUNCTIONS'):
                        functions.update(module.FUNCTIONS)
            except Exception as e:
                print(f"Warning: Could not load functions from {filename}: {e}")
    
    return functions


__all__ = ['load_custom_functions']
