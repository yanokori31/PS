"""
Unicode Formatter for PCS - converts mathematical expressions to Unicode format.
"""

from typing import Dict, Any, Union
from fractions import Fraction


class UnicodeFormatter:
    OPERATOR_MAP = {
        '*': '\u00d7',
        '/': '\u00f7',
        '+': '+',
        '-': '\u2212',
        '=': '=',
        '!=': '\u2260',
        '<=': '\u2264',
        '>=': '\u2265',
        'sqrt': '\u221a',
        'pi': '\u03c0',
        'inf': '\u221e',
        '^2': '\u00b2',
        '^3': '\u00b3',
        '^4': '\u2074',
        '^5': '\u2075',
        '^6': '\u2076',
        '^7': '\u2077',
        '^8': '\u2078',
        '^9': '\u2079',
        '^0': '\u2070',
        '^n': '\u207f',
    }
    
    SUBSCRIPT_MAP = {
        '0': '\u2080',
        '1': '\u2081',
        '2': '\u2082',
        '3': '\u2083',
        '4': '\u2084',
        '5': '\u2085',
        '6': '\u2086',
        '7': '\u2087',
        '8': '\u2088',
        '9': '\u2089',
    }
    
    SUPERSCRIPT_MAP = {
        '0': '\u2070',
        '1': '\u00b9',
        '2': '\u00b2',
        '3': '\u00b3',
        '4': '\u2074',
        '5': '\u2075',
        '6': '\u2076',
        '7': '\u2077',
        '8': '\u2078',
        '9': '\u2079',
        '+': '\u207a',
        '-': '\u207b',
        'n': '\u207f',
    }
    
    FRACTION_CHARS = {
        (1, 2): '\u00bd',
        (1, 3): '\u2153',
        (2, 3): '\u2154',
        (1, 4): '\u00bc',
        (3, 4): '\u00be',
        (1, 5): '\u2155',
        (2, 5): '\u2156',
        (3, 5): '\u2157',
        (4, 5): '\u2158',
        (1, 6): '\u2159',
        (5, 6): '\u215a',
        (1, 7): '\u2150',
        (1, 8): '\u215b',
        (3, 8): '\u215c',
        (5, 8): '\u215d',
        (7, 8): '\u215e',
        (1, 9): '\u2151',
        (1, 10): '\u2152',
    }
    
    @classmethod
    def format_expression(cls, expr: str) -> str:
        result = expr
        for old, new in cls.OPERATOR_MAP.items():
            if old in result and len(old) > 0:
                result = result.replace(old, new)
        return result
    
    @classmethod
    def format_superscript(cls, text: str) -> str:
        result = ''
        for char in text:
            if char in cls.SUPERSCRIPT_MAP:
                result += cls.SUPERSCRIPT_MAP[char]
            else:
                result += char
        return result
    
    @classmethod
    def format_subscript(cls, text: str) -> str:
        result = ''
        for char in text:
            if char in cls.SUBSCRIPT_MAP:
                result += cls.SUBSCRIPT_MAP[char]
            else:
                result += char
        return result
    
    @classmethod
    def format_power(cls, base: str, exponent: str) -> str:
        return f"{base}{cls.format_superscript(exponent)}"
    
    @classmethod
    def format_fraction(cls, numerator: int, denominator: int) -> str:
        if denominator == 0:
            return "undefined"
        
        if denominator < 0:
            numerator = -numerator
            denominator = -denominator
        
        from math import gcd
        g = gcd(abs(numerator), denominator)
        num = numerator // g
        den = denominator // g
        
        if den == 1:
            return str(num)
        
        if (abs(num), den) in cls.FRACTION_CHARS:
            sign = '' if num >= 0 else '-'
            return f"{sign}{cls.FRACTION_CHARS[(abs(num), den)]}"
        
        return f"{num}/{den}"
    
    @classmethod
    def format_fraction_stacked(cls, numerator: int, denominator: int) -> str:
        if denominator == 0:
            return "undefined"
            
        from math import gcd
        g = gcd(abs(numerator), abs(denominator))
        num = numerator // g
        den = abs(denominator) // g
        
        if denominator < 0:
            num = -num
        
        if den == 1:
            return str(num)
        
        num_str = str(abs(num))
        den_str = str(den)
        width = max(len(num_str), len(den_str))
        
        sign = "-" if num < 0 else " "
        
        horizontal_line = "\u2500" * width
        
        lines = [
            f"{sign}{num_str.center(width)}",
            f" {horizontal_line}",
            f" {den_str.center(width)}"
        ]
        return "\n".join(lines)
    
    @classmethod
    def format_mixed_fraction(cls, whole: int, numerator: int, denominator: int) -> str:
        if denominator == 0:
            return "undefined"
        
        from math import gcd
        g = gcd(abs(numerator), abs(denominator))
        num = numerator // g
        den = abs(denominator) // g
        
        if den == 1:
            return str(whole + num)
        
        frac_part = cls.format_fraction(abs(num), den)
        
        if whole == 0:
            if num < 0:
                return f"-{frac_part}"
            return frac_part
        
        sign = "" if whole >= 0 else "-"
        return f"{sign}{abs(whole)} {frac_part}"
    
    @classmethod
    def format_result(cls, value: Any, display_type: str = "number") -> str:
        if isinstance(value, Fraction):
            if abs(value) >= 1:
                whole = int(value)
                remainder = value - whole
                if remainder != 0:
                    return cls.format_mixed_fraction(
                        whole, 
                        remainder.numerator, 
                        remainder.denominator
                    )
                return str(whole)
            return cls.format_fraction(value.numerator, value.denominator)
        
        if isinstance(value, float):
            if value == int(value):
                return str(int(value))
            return f"{value:.10g}"
        
        return str(value)
    
    @classmethod
    def to_alphanumeric(cls, expr: str) -> str:
        reverse_map = {v: k for k, v in cls.OPERATOR_MAP.items()}
        result = expr
        for unicode_char, ascii_char in reverse_map.items():
            result = result.replace(unicode_char, ascii_char)
        return result
