"""
Tokenizer for PCS - converts input string into tokens.
"""

import re
from typing import List, Tuple, Optional
from enum import Enum, auto


class TokenType(Enum):
    NUMBER = auto()
    PLUS = auto()
    MINUS = auto()
    MULTIPLY = auto()
    DIVIDE = auto()
    LPAREN = auto()
    RPAREN = auto()
    COMMA = auto()
    FUNCTION = auto()
    EOF = auto()


class Token:
    def __init__(self, type_: TokenType, value, position: int = 0):
        self.type = type_
        self.value = value
        self.position = position
    
    def __repr__(self):
        return f"Token({self.type.name}, {self.value})"
    
    def __eq__(self, other):
        if isinstance(other, Token):
            return self.type == other.type and self.value == other.value
        return False


class Tokenizer:
    OPERATORS = {
        '+': TokenType.PLUS,
        '-': TokenType.MINUS,
        '*': TokenType.MULTIPLY,
        '/': TokenType.DIVIDE,
        '(': TokenType.LPAREN,
        ')': TokenType.RPAREN,
        ',': TokenType.COMMA,
        '\u00d7': TokenType.MULTIPLY,
        '\u00f7': TokenType.DIVIDE,
    }
    
    def __init__(self, text: str):
        self.text = text
        self.pos = 0
        self.current_char: Optional[str] = self.text[0] if text else None
    
    def advance(self):
        self.pos += 1
        if self.pos < len(self.text):
            self.current_char = self.text[self.pos]
        else:
            self.current_char = None
    
    def skip_whitespace(self):
        while self.current_char is not None and self.current_char.isspace():
            self.advance()
    
    def read_number(self) -> Token:
        start_pos = self.pos
        result = ''
        has_dot = False
        
        while self.current_char is not None and (self.current_char.isdigit() or self.current_char == '.'):
            if self.current_char == '.':
                if has_dot:
                    break
                has_dot = True
            result += self.current_char
            self.advance()
        
        if has_dot:
            return Token(TokenType.NUMBER, float(result), start_pos)
        return Token(TokenType.NUMBER, int(result), start_pos)
    
    def read_identifier(self) -> Token:
        start_pos = self.pos
        result = ''
        
        while self.current_char is not None and (self.current_char.isalnum() or self.current_char == '_'):
            result += self.current_char
            self.advance()
        
        return Token(TokenType.FUNCTION, result, start_pos)
    
    def tokenize(self) -> List[Token]:
        tokens = []
        
        while self.current_char is not None:
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            
            if self.current_char.isdigit() or (self.current_char == '.' and self.pos + 1 < len(self.text) and self.text[self.pos + 1].isdigit()):
                tokens.append(self.read_number())
                continue
            
            if self.current_char.isalpha() or self.current_char == '_':
                tokens.append(self.read_identifier())
                continue
            
            if self.current_char in self.OPERATORS:
                token_type = self.OPERATORS[self.current_char]
                tokens.append(Token(token_type, self.current_char, self.pos))
                self.advance()
                continue
            
            raise ValueError(f"Unknown character '{self.current_char}' at position {self.pos}")
        
        tokens.append(Token(TokenType.EOF, None, self.pos))
        return tokens
